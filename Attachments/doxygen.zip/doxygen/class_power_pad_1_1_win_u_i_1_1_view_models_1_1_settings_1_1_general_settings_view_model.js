var class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model =
[
    [ "InitializeAIServices", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#ad02eefc3ae6c1e8921f574eb3eb4c6c5", null ],
    [ "AcrylicBackground", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#acf01434a3e29504e610d821cd8499608", null ],
    [ "AgentPrompt", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#a7d8e17d38c1bd330013f5d20b8e2187c", null ],
    [ "AppTheme", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#af507a23c56e24bd6c57288ad2ee1622c", null ],
    [ "AvailableProviders", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#ad875e94210d5fc144b6ca2d1b9a67ba6", null ],
    [ "AzureAIConfig", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#a398d34183a2d5598385672886e7ea5b0", null ],
    [ "AzureAIEnabled", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#afc5732d8a01a77dd02e1b7c7d2e2d7c4", null ],
    [ "EnableHotKeys", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#a4cc9f56efb8cc82b438b901f293b980f", null ],
    [ "OllamaAutostart", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#ade70584354e916fca9b83aa3494795b6", null ],
    [ "OllamaConfig", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#a379e9b285bb85c2864647f2d7cf6b2e7", null ],
    [ "OllamaEnabled", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#ac47ed4d4ce7fb6e4e709a601b910cdd7", null ],
    [ "OpenAIConfig", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#ab2f1ade1c2b062c49af62e7d6af2ef25", null ],
    [ "OpenAIEnabled", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#ab3a705054881e42adea72db652d44156", null ],
    [ "ProviderAvailabilityChanged", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#ae7ec357134e1f8994fd17e0d52e3cca3", null ],
    [ "ServiceEnablementChanged", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#a90fb8c6f0d8ad9f873834e2e3da4a85c", null ]
];