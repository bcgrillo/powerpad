var class_power_pad_1_1_win_u_i_1_1_view_models_1_1_chat_1_1_chat_view_model =
[
    [ "ChatViewModel", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_chat_1_1_chat_view_model.html#a66c2ea339e648440876290b90c3a18a2", null ],
    [ "AgentId", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_chat_1_1_chat_view_model.html#a7d5886a514f2d3cb6a73e3b922126423", null ],
    [ "ChatError", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_chat_1_1_chat_view_model.html#a051710305c22fe0102f8d16aa9b0f5d7", null ],
    [ "ClearMessagesCommand", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_chat_1_1_chat_view_model.html#ac4447e387c243607cb57c0d9664236c4", null ],
    [ "Messages", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_chat_1_1_chat_view_model.html#aa112c1f6a415d389bc6c0d58882466ee", null ],
    [ "Model", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_chat_1_1_chat_view_model.html#a2fe13f09f31bcd91f5031818cdac2a8b", null ],
    [ "Parameters", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_chat_1_1_chat_view_model.html#a9c2cb021a0af19eb6606053b56e8b187", null ],
    [ "RemoveLastMessageCommand", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_chat_1_1_chat_view_model.html#ac21c5e788f52df0088f29741f336f5ab", null ]
];