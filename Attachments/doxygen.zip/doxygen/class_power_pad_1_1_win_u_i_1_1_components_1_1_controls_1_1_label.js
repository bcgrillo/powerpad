var class_power_pad_1_1_win_u_i_1_1_components_1_1_controls_1_1_label =
[
    [ "Label", "class_power_pad_1_1_win_u_i_1_1_components_1_1_controls_1_1_label.html#aa1f5da07a83abd352f556990860304f8", null ],
    [ "Text", "class_power_pad_1_1_win_u_i_1_1_components_1_1_controls_1_1_label.html#a42bfc237e053ee7398ecb398cece833a", null ]
];