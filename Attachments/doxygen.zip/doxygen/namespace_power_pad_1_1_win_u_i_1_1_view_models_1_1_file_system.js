var namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system =
[
    [ "DocumentViewModel", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model.html", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model" ],
    [ "DraftDocumentViewModel", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_draft_document_view_model.html", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_draft_document_view_model" ],
    [ "FolderEntryViewModel", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_folder_entry_view_model.html", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_folder_entry_view_model" ],
    [ "NewEntryParameters", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_new_entry_parameters.html", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_new_entry_parameters" ],
    [ "WorkspaceViewModel", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_workspace_view_model.html", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_workspace_view_model" ],
    [ "DocumentType", "namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system.html#a0d168e59eaad3e26463c5831204ed308", [
      [ "Note", "namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system.html#a0d168e59eaad3e26463c5831204ed308a3b0649c72650c313a357338dcdfb64ec", null ],
      [ "Chat", "namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system.html#a0d168e59eaad3e26463c5831204ed308a55dcdf017b51fc96f7b5f9d63013b95d", null ]
    ] ],
    [ "MoveEntryParameters", "namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system.html#afa3f4b83202ecbc27fa0ce8b73765e33", null ]
];