var searchData=
[
  ['agenticontype_0',['AgentIconType',['../namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_agents.html#a35083ebee43b3d1fb55e8f668632c02e',1,'PowerPad::WinUI::ViewModels::Agents']]]
];
