var searchData=
[
  ['huggingface_0',['HuggingFace',['../namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#adb47f579c74b3af19e1632470ba10a6bae0b6bb846c6a3e0649ce0e3cd9355df3',1,'PowerPad::Core::Models::AI']]]
];
