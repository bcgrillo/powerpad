var searchData=
[
  ['label_0',['Label',['../class_power_pad_1_1_win_u_i_1_1_components_1_1_controls_1_1_label.html',1,'PowerPad::WinUI::Components::Controls']]]
];
