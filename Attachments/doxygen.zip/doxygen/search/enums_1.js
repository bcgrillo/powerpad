var searchData=
[
  ['documentstatus_0',['DocumentStatus',['../namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html#ae5f6280ba550d21e1a4f53bb9e6d5fff',1,'PowerPad::Core::Models::FileSystem']]],
  ['documenttype_1',['DocumentType',['../namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system.html#a0d168e59eaad3e26463c5831204ed308',1,'PowerPad::WinUI::ViewModels::FileSystem']]]
];
