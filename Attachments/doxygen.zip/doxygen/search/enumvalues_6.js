var searchData=
[
  ['github_0',['GitHub',['../namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#adb47f579c74b3af19e1632470ba10a6bad3b7c913cd04ebfec0e9ec32cb6fd58c',1,'PowerPad::Core::Models::AI']]]
];
