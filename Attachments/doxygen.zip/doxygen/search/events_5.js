var searchData=
[
  ['modelavailabilitychanged_0',['ModelAvailabilityChanged',['../class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_models_settings_view_model.html#a3f0a1433a2307d0bcfb181788ea42e65',1,'PowerPad::WinUI::ViewModels::Settings::ModelsSettingsViewModel']]],
  ['modelinfoviewervisibilitychanged_1',['ModelInfoViewerVisibilityChanged',['../class_power_pad_1_1_win_u_i_1_1_components_1_1_available_models_repeater.html#a867d385eaac5a4edc90a09f9f5372bfb',1,'PowerPad.WinUI.Components.AvailableModelsRepeater.ModelInfoViewerVisibilityChanged'],['../class_power_pad_1_1_win_u_i_1_1_components_1_1_search_models_result_repeater.html#a22262b11b7e4eb47157453da57fc44ed',1,'PowerPad.WinUI.Components.SearchModelsResultRepeater.ModelInfoViewerVisibilityChanged']]]
];
