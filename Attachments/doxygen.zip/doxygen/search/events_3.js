var searchData=
[
  ['edited_0',['Edited',['../class_power_pad_1_1_win_u_i_1_1_components_1_1_controls_1_1_editable_text_block.html#a3de6d325241021905e897fe6b9fb07fa',1,'PowerPad::WinUI::Components::Controls::EditableTextBlock']]]
];
