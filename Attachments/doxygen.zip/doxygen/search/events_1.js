var searchData=
[
  ['chatoptionschanged_0',['ChatOptionsChanged',['../class_power_pad_1_1_win_u_i_1_1_components_1_1_controls_1_1_chat_control.html#a3e43fe3e2545a5f6aba916140ad03331',1,'PowerPad::WinUI::Components::Controls::ChatControl']]],
  ['closerequested_1',['CloseRequested',['../class_power_pad_1_1_win_u_i_1_1_pages_1_1_popup_editor_page.html#ab15cda7b0ecc7a399df8e5628a999b2e',1,'PowerPad::WinUI::Pages::PopupEditorPage']]]
];
