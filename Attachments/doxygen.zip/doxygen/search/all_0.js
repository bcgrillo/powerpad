var searchData=
[
  ['_5faiservice_0',['_aiService',['../class_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers_1_1_a_i_models_view_model_base.html#a2b798229bba2c655a947d68013457cfc',1,'PowerPad::WinUI::ViewModels::AI::Providers::AIModelsViewModelBase']]],
  ['_5fmodelprovider_1',['_modelProvider',['../class_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers_1_1_a_i_models_view_model_base.html#adf6100720be3518517d2de39cbf62e79',1,'PowerPad::WinUI::ViewModels::AI::Providers::AIModelsViewModelBase']]],
  ['_5fsearchcompleted_2',['_searchCompleted',['../class_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers_1_1_a_i_models_view_model_base.html#aa50b52b9e9df982a5a81b3e020b34e51',1,'PowerPad::WinUI::ViewModels::AI::Providers::AIModelsViewModelBase']]],
  ['_5fsettings_3',['_settings',['../class_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers_1_1_a_i_models_view_model_base.html#a5afc802cd60514641164b1e2f691e268',1,'PowerPad::WinUI::ViewModels::AI::Providers::AIModelsViewModelBase']]]
];
