var searchData=
[
  ['popupeditorpage_0',['PopupEditorPage',['../class_power_pad_1_1_win_u_i_1_1_pages_1_1_popup_editor_page.html',1,'PowerPad::WinUI::Pages']]],
  ['popupwindow_1',['PopupWindow',['../class_power_pad_1_1_win_u_i_1_1_popup_window.html',1,'PowerPad::WinUI']]]
];
