var searchData=
[
  ['iteminvoked_0',['ItemInvoked',['../class_power_pad_1_1_win_u_i_1_1_components_1_1_workspace_control.html#a6cb9ac6c66ed80a5023f483e4ed3f10c',1,'PowerPad::WinUI::Components::WorkspaceControl']]]
];
