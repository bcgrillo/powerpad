var searchData=
[
  ['newentryparameters_0',['NewEntryParameters',['../class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_new_entry_parameters.html',1,'PowerPad::WinUI::ViewModels::FileSystem']]],
  ['noteagentcontrol_1',['NoteAgentControl',['../class_power_pad_1_1_win_u_i_1_1_components_1_1_controls_1_1_note_agent_control.html',1,'PowerPad::WinUI::Components::Controls']]]
];
