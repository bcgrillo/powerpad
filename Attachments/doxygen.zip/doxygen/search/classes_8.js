var searchData=
[
  ['iaiservice_0',['IAIService',['../interface_power_pad_1_1_core_1_1_contracts_1_1_i_a_i_service.html',1,'PowerPad::Core::Contracts']]],
  ['ichatservice_1',['IChatService',['../interface_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_i_chat_service.html',1,'PowerPad::Core::Services::AI']]],
  ['iconfigstore_2',['IConfigStore',['../interface_power_pad_1_1_core_1_1_services_1_1_config_1_1_i_config_store.html',1,'PowerPad::Core::Services::Config']]],
  ['iconfigstoreservice_3',['IConfigStoreService',['../interface_power_pad_1_1_core_1_1_services_1_1_config_1_1_i_config_store_service.html',1,'PowerPad::Core::Services::Config']]],
  ['idocumentservice_4',['IDocumentService',['../interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_document_service.html',1,'PowerPad::Core::Services::FileSystem']]],
  ['ieditorcontract_5',['IEditorContract',['../interface_power_pad_1_1_core_1_1_contracts_1_1_i_editor_contract.html',1,'PowerPad::Core::Contracts']]],
  ['ifolderentry_6',['IFolderEntry',['../interface_power_pad_1_1_core_1_1_contracts_1_1_i_folder_entry.html',1,'PowerPad::Core::Contracts']]],
  ['imodelproviderpage_7',['IModelProviderPage',['../interface_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_i_model_provider_page.html',1,'PowerPad::WinUI::Pages::Providers']]],
  ['integratedtextbox_8',['IntegratedTextBox',['../class_power_pad_1_1_win_u_i_1_1_components_1_1_controls_1_1_integrated_text_box.html',1,'PowerPad::WinUI::Components::Controls']]],
  ['inttodoubleconverter_9',['IntToDoubleConverter',['../class_power_pad_1_1_win_u_i_1_1_converters_1_1_int_to_double_converter.html',1,'PowerPad::WinUI::Converters']]],
  ['iollamaservice_10',['IOllamaService',['../interface_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_i_ollama_service.html',1,'PowerPad::Core::Services::AI']]],
  ['iorderservice_11',['IOrderService',['../interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_order_service.html',1,'PowerPad::Core::Services::FileSystem']]],
  ['itogglemenupage_12',['IToggleMenuPage',['../interface_power_pad_1_1_win_u_i_1_1_pages_1_1_i_toggle_menu_page.html',1,'PowerPad::WinUI::Pages']]],
  ['iworkspaceservice_13',['IWorkspaceService',['../interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service.html',1,'PowerPad::Core::Services::FileSystem']]]
];
