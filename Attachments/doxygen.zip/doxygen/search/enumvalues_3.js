var searchData=
[
  ['dirty_0',['Dirty',['../namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html#ae5f6280ba550d21e1a4f53bb9e6d5fffa99feffc57dae9a01652065178fae5b19',1,'PowerPad::Core::Models::FileSystem']]],
  ['document_1',['Document',['../namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html#a835ab05beb7c1a5efca9dc162e28e311a0945359809dad1fbf3dea1c95a0da951',1,'PowerPad::Core::Models::FileSystem']]]
];
