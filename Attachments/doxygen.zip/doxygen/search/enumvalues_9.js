var searchData=
[
  ['ollama_0',['Ollama',['../namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#adb47f579c74b3af19e1632470ba10a6bac23e8db458397f37c8e8d98e94e55a18',1,'PowerPad::Core::Models::AI']]],
  ['online_1',['Online',['../namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#a36f2dfb3b4c12a195955249a38b476b8a54f664c70c22054ea0d8d26fc3997ce7',1,'PowerPad::Core::Models::AI']]],
  ['openai_2',['OpenAI',['../namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#adb47f579c74b3af19e1632470ba10a6ba0523b13262b12c215d8009938f5c14f1',1,'PowerPad::Core::Models::AI']]]
];
