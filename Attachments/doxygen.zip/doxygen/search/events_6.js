var searchData=
[
  ['parametersvisibilitychanged_0',['ParametersVisibilityChanged',['../class_power_pad_1_1_win_u_i_1_1_components_1_1_controls_1_1_chat_control.html#aaabb0528fc127af1992ff0ecf20aac44',1,'PowerPad::WinUI::Components::Controls::ChatControl']]],
  ['provideravailabilitychanged_1',['ProviderAvailabilityChanged',['../class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_general_settings_view_model.html#ae7ec357134e1f8994fd17e0d52e3cca3',1,'PowerPad::WinUI::ViewModels::Settings::GeneralSettingsViewModel']]]
];
