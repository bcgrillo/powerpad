var searchData=
[
  ['folder_0',['Folder',['../namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html#a835ab05beb7c1a5efca9dc162e28e311ab0f2b97dc5d2b76b26e040408bb1d8af',1,'PowerPad::Core::Models::FileSystem']]],
  ['fonticonglyph_1',['FontIconGlyph',['../namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_agents.html#a35083ebee43b3d1fb55e8f668632c02ea0d679cc95da1d2cf3074594a4901df57',1,'PowerPad::WinUI::ViewModels::Agents']]]
];
