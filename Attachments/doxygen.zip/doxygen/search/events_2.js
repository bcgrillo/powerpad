var searchData=
[
  ['defaultmodelchanged_0',['DefaultModelChanged',['../class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_models_settings_view_model.html#a59044d5a2c58507673abafee66fb53e2',1,'PowerPad::WinUI::ViewModels::Settings::ModelsSettingsViewModel']]],
  ['deleteclick_1',['DeleteClick',['../class_power_pad_1_1_win_u_i_1_1_components_1_1_available_models_repeater.html#afffccf335c1335391910ce870de9c409',1,'PowerPad::WinUI::Components::AvailableModelsRepeater']]]
];
