var searchData=
[
  ['note_0',['Note',['../namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system.html#a0d168e59eaad3e26463c5831204ed308a3b0649c72650c313a357338dcdfb64ec',1,'PowerPad::WinUI::ViewModels::FileSystem']]],
  ['notfound_1',['NotFound',['../namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#a36f2dfb3b4c12a195955249a38b476b8a38c300f4fc9ce8a77aad4a30de05cad8',1,'PowerPad::Core::Models::AI']]]
];
