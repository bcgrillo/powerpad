var searchData=
[
  ['huggingfaceaddmodelpage_0',['HuggingFaceAddModelPage',['../class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_add_model_page.html',1,'PowerPad::WinUI::Pages::Providers']]],
  ['huggingfacemodelspage_1',['HuggingFaceModelsPage',['../class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_models_page.html',1,'PowerPad::WinUI::Pages::Providers']]],
  ['huggingfacemodelsviewmodel_2',['HuggingFaceModelsViewModel',['../class_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers_1_1_hugging_face_models_view_model.html',1,'PowerPad::WinUI::ViewModels::AI::Providers']]]
];
