var searchData=
[
  ['menuoption_0',['MenuOption',['../namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i.html#a9c47916a3d43feafb245ecbe13b78905',1,'PowerPad::WinUI::ViewModels::AI']]],
  ['modelprovider_1',['ModelProvider',['../namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#adb47f579c74b3af19e1632470ba10a6b',1,'PowerPad::Core::Models::AI']]]
];
