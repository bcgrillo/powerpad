var class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_open_a_i_models_page =
[
    [ "OpenAIModelsPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_open_a_i_models_page.html#a1dabf9dfbbdb856bf627f0312e9fce5e", null ],
    [ "CloseModelInfoViewer", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_open_a_i_models_page.html#aff083a329972db3701976866e43bcfd1", null ]
];