var class_power_pad_1_1_win_u_i_1_1_converters_1_1_service_status_to_bool_negation_converter =
[
    [ "Convert", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_service_status_to_bool_negation_converter.html#a02ac06a8466adb729d4c5f4fd56dcd14", null ],
    [ "ConvertBack", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_service_status_to_bool_negation_converter.html#abe2c25d65ac82bf2e1b0e6eb5bc05702", null ]
];