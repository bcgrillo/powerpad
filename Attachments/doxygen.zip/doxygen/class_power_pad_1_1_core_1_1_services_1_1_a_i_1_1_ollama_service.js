var class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_ollama_service =
[
    [ "ChatClient", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_ollama_service.html#ad156e915e9660fdaa8e3e860c92091d5", null ],
    [ "DeleteModel", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_ollama_service.html#ad9f74b06e51278d7dc3ac7d2dad47967", null ],
    [ "DownloadModel", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_ollama_service.html#abb12fad5cda86167a5f671350aeb6668", null ],
    [ "GetInstalledModels", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_ollama_service.html#a6db9216484d457fa831eaac02bbfadcb", null ],
    [ "Initialize", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_ollama_service.html#aa0dc4d2768af54965e13413e99dccee8", null ],
    [ "SearchModels", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_ollama_service.html#ac9d496a96aeea0c046f733c0d068d2a8", null ],
    [ "Start", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_ollama_service.html#a41c326a754a12c48743902e571ed9389", null ],
    [ "Stop", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_ollama_service.html#a4c6ac36abc12c316a94bd61ff1445e72", null ],
    [ "TestConnection", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_ollama_service.html#af429825a0505c90df709ef39d6fc5a80", null ]
];