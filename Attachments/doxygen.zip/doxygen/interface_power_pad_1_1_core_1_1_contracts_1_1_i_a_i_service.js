var interface_power_pad_1_1_core_1_1_contracts_1_1_i_a_i_service =
[
    [ "ChatClient", "interface_power_pad_1_1_core_1_1_contracts_1_1_i_a_i_service.html#a075a2e7e9d2b519f838003e92ff90f80", null ],
    [ "Initialize", "interface_power_pad_1_1_core_1_1_contracts_1_1_i_a_i_service.html#a36cbd0a7ee735db9902468171a1ff3e1", null ],
    [ "SearchModels", "interface_power_pad_1_1_core_1_1_contracts_1_1_i_a_i_service.html#a35edacdeeaecebad3da34bb6bd2f4ce1", null ],
    [ "TestConnection", "interface_power_pad_1_1_core_1_1_contracts_1_1_i_a_i_service.html#a8dd7215e9667d957bb7240409bbcd180", null ]
];