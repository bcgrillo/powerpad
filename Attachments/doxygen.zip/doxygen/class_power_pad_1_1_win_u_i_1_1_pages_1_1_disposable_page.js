var class_power_pad_1_1_win_u_i_1_1_pages_1_1_disposable_page =
[
    [ "DisposablePage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_disposable_page.html#a55a384d12bb7fdae8adc53ecbd45a1b8", null ],
    [ "Dispose", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_disposable_page.html#a41257bb532ffc4b62cb48952900a3ee3", null ],
    [ "Dispose", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_disposable_page.html#ac3cde1ac40b7be925992770d01956532", null ]
];