var class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_models_page =
[
    [ "HuggingFaceModelsPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_models_page.html#a6abbf47d09cfa88ea1099feb7479b228", null ],
    [ "CloseModelInfoViewer", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_models_page.html#a5d5b7678a65a39e08d1fd492b1040acd", null ]
];