var namespace_power_pad_1_1_core_1_1_models =
[
    [ "AI", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html", [
      [ "ModelProvider", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#adb47f579c74b3af19e1632470ba10a6b", [
        [ "Ollama", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#adb47f579c74b3af19e1632470ba10a6bac23e8db458397f37c8e8d98e94e55a18", null ],
        [ "HuggingFace", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#adb47f579c74b3af19e1632470ba10a6bae0b6bb846c6a3e0649ce0e3cd9355df3", null ],
        [ "GitHub", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#adb47f579c74b3af19e1632470ba10a6bad3b7c913cd04ebfec0e9ec32cb6fd58c", null ],
        [ "OpenAI", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#adb47f579c74b3af19e1632470ba10a6ba0523b13262b12c215d8009938f5c14f1", null ]
      ] ],
      [ "ServiceStatus", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#a36f2dfb3b4c12a195955249a38b476b8", [
        [ "Unknown", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#a36f2dfb3b4c12a195955249a38b476b8a88183b946cc5f0e8c96b2e66e1c74a7e", null ],
        [ "Unconfigured", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#a36f2dfb3b4c12a195955249a38b476b8af5d49bc3243ac8419db1a2a0c448d1f3", null ],
        [ "Updating", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#a36f2dfb3b4c12a195955249a38b476b8a6909beea5b50605780e3411f879fe916", null ],
        [ "Available", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#a36f2dfb3b4c12a195955249a38b476b8a78945de8de090e90045d299651a68a9b", null ],
        [ "Online", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#a36f2dfb3b4c12a195955249a38b476b8a54f664c70c22054ea0d8d26fc3997ce7", null ],
        [ "Error", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#a36f2dfb3b4c12a195955249a38b476b8a902b0d55fddef6f8d651fe1035b7d4bd", null ],
        [ "NotFound", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#a36f2dfb3b4c12a195955249a38b476b8a38c300f4fc9ce8a77aad4a30de05cad8", null ]
      ] ],
      [ "AIModel", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#accd0397490072f526017ef6ada21b876", null ],
      [ "AIParameters", "namespace_power_pad_1_1_core_1_1_models_1_1_a_i.html#a6f1d34f8591b5add11e2570452779120", null ]
    ] ],
    [ "FileSystem", "namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html", [
      [ "DocumentStatus", "namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html#ae5f6280ba550d21e1a4f53bb9e6d5fff", [
        [ "Unloaded", "namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html#ae5f6280ba550d21e1a4f53bb9e6d5fffaa5ae20aa7fda5bd38bf0dce98e65bd2d", null ],
        [ "Dirty", "namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html#ae5f6280ba550d21e1a4f53bb9e6d5fffa99feffc57dae9a01652065178fae5b19", null ],
        [ "AutoSaved", "namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html#ae5f6280ba550d21e1a4f53bb9e6d5fffa8624e5a0fd946d14e57e4736f9d206de", null ],
        [ "Saved", "namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html#ae5f6280ba550d21e1a4f53bb9e6d5fffa248336101b461380a4b2391a7625493d", null ]
      ] ],
      [ "EntryType", "namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html#a835ab05beb7c1a5efca9dc162e28e311", [
        [ "Folder", "namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html#a835ab05beb7c1a5efca9dc162e28e311ab0f2b97dc5d2b76b26e040408bb1d8af", null ],
        [ "Document", "namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html#a835ab05beb7c1a5efca9dc162e28e311a0945359809dad1fbf3dea1c95a0da951", null ]
      ] ],
      [ "Root", "namespace_power_pad_1_1_core_1_1_models_1_1_file_system.html#a813e924ca586759d24f56f57dd660b7d", null ]
    ] ]
];