var class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_chat_editor_control =
[
    [ "ChatEditorControl", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_chat_editor_control.html#acbe5b9dd795780bb92d972fd640c0731", null ],
    [ "AutoSave", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_chat_editor_control.html#a235d4b3dc0b530abfa8be5ce1228005f", null ],
    [ "Dispose", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_chat_editor_control.html#a531635171111c31c39ac59fed32858ad", null ],
    [ "GetContent", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_chat_editor_control.html#ab91093fb38e49d7347a18a2cf87a495d", null ],
    [ "SetContent", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_chat_editor_control.html#ad3be8f4a6d440722485c68e4ecb33426", null ],
    [ "SetFocus", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_chat_editor_control.html#abcb38f895bc3c3a7b0de878945db101d", null ],
    [ "WordCount", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_chat_editor_control.html#a8449daa31b249c38069514cc1a82d1c7", null ],
    [ "IsDirty", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_chat_editor_control.html#a264219f24eda041e1d72d6f1167e6d38", null ],
    [ "LastSaveTime", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_chat_editor_control.html#a5dbe176640d9a5c037947c64222facc6", null ]
];