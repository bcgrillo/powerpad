var namespace_power_pad_1_1_win_u_i_1_1_dialogs =
[
    [ "DialogHelper", "class_power_pad_1_1_win_u_i_1_1_dialogs_1_1_dialog_helper.html", null ],
    [ "OllamaDownloadHelper", "class_power_pad_1_1_win_u_i_1_1_dialogs_1_1_ollama_download_helper.html", null ]
];