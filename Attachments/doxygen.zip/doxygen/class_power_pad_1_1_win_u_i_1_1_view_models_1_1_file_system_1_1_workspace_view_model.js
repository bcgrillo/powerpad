var class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_workspace_view_model =
[
    [ "WorkspaceViewModel", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_workspace_view_model.html#aff8762dbd17bab8ad3aa1b92adf4835d", null ],
    [ "CurrentDocumentPath", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_workspace_view_model.html#adab3e7c45705f8599dc8ef6a30286a9a", null ],
    [ "MoveEntryCommand", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_workspace_view_model.html#a455b34eb999ebfa3e379b5b4a58bbb06", null ],
    [ "NewEntryCommand", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_workspace_view_model.html#aa88c247fe03537b0152df77bd5021e7a", null ],
    [ "OpenWorkspaceCommand", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_workspace_view_model.html#a325f34cfdaff5e5628ae5dfcd13b9617", null ],
    [ "RecentlyWorkspaces", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_workspace_view_model.html#af19588b8c17d3acf3d601dc443b361f3", null ],
    [ "Root", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_workspace_view_model.html#aa783ba61c42db733d1aa15a86e2bdbb2", null ]
];