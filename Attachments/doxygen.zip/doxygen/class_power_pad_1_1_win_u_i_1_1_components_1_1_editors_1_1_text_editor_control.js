var class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_text_editor_control =
[
    [ "TextEditorControl", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_text_editor_control.html#a16ec964585935bef40be83c3aca821e9", null ],
    [ "AutoSave", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_text_editor_control.html#abfaf32c90dea4bb6bea5d5522e95ac3d", null ],
    [ "Dispose", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_text_editor_control.html#a74c66662e67eebfa5e3f9273733c404e", null ],
    [ "GetContent", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_text_editor_control.html#a876c3131ab2c247143e7734804227f8e", null ],
    [ "SetContent", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_text_editor_control.html#ac28dc19bc606bd5268d1dbe77fd9b649", null ],
    [ "SetFocus", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_text_editor_control.html#a4d1c86ecadf0cbf3343e9c193dc87c67", null ],
    [ "WordCount", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_text_editor_control.html#a2194dcc1a621f170b84bfcc37cf0cc1d", null ],
    [ "IsDirty", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_text_editor_control.html#a9a7028086e25c5da95b663411cdc742c", null ],
    [ "LastSaveTime", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_text_editor_control.html#a7a954439248d8b96caa780088ac9a335", null ]
];