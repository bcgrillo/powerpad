var class_power_pad_1_1_win_u_i_1_1_converters_1_1_int_to_double_converter =
[
    [ "Convert", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_int_to_double_converter.html#a96022487377b9c8f6cd30040bbbf8b93", null ],
    [ "ConvertBack", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_int_to_double_converter.html#aa430dcc3084c03c32efa648174149f64", null ]
];