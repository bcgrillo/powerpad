var class_power_pad_1_1_win_u_i_1_1_pages_1_1_agents_page =
[
    [ "AgentsPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_agents_page.html#afaa9ebff31a3a299359304fbda0435c1", null ],
    [ "Dispose", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_agents_page.html#ad68c5157005307eee9e99ae90c5745d7", null ],
    [ "ToggleNavigationVisibility", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_agents_page.html#a6c5957d1acd1c5dcf7a08b57719ef6ca", null ],
    [ "NavigationWidth", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_agents_page.html#ad367ca31c81cc4523f470e5fa96e221c", null ]
];