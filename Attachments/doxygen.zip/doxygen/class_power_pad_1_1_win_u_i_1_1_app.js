var class_power_pad_1_1_win_u_i_1_1_app =
[
    [ "App", "class_power_pad_1_1_win_u_i_1_1_app.html#a56d7885d6532440541b5b043159b4960", null ],
    [ "OnLaunched", "class_power_pad_1_1_win_u_i_1_1_app.html#a5c4eebedf9d034138901717f95bcee94", null ]
];