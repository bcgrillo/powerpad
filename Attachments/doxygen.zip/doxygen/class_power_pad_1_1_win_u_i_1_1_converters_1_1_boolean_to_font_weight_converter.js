var class_power_pad_1_1_win_u_i_1_1_converters_1_1_boolean_to_font_weight_converter =
[
    [ "Convert", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_boolean_to_font_weight_converter.html#a907862756999505862eb87562681dd9d", null ],
    [ "ConvertBack", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_boolean_to_font_weight_converter.html#ae7e4d68642617a7fd0dcc5a7f2aac0c7", null ]
];