var class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_azure_a_i_service =
[
    [ "ChatClient", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_azure_a_i_service.html#a10e4fce41ab3d96beb19a029f80f8b9d", null ],
    [ "Initialize", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_azure_a_i_service.html#a77f24d265918f88e66eec09155d7022b", null ],
    [ "SearchModels", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_azure_a_i_service.html#a8bc9a241f4bf4d0e90eb5f1369908dc3", null ],
    [ "TestConnection", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_azure_a_i_service.html#afc474b164d37d7708ebdec7279ecf871", null ]
];