var class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_open_a_i_service =
[
    [ "ChatClient", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_open_a_i_service.html#a54730898d3ced86f1dbfed8ee39f3b75", null ],
    [ "Initialize", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_open_a_i_service.html#a6bd80a076aeeb3ef1e796e8031e7bb1a", null ],
    [ "SearchModels", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_open_a_i_service.html#a17f590d1976d882e8084eb2052f8da38", null ],
    [ "TestConnection", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_open_a_i_service.html#a12542f1b864d55b82266f4f6e307648d", null ]
];