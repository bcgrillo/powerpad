var interface_power_pad_1_1_core_1_1_contracts_1_1_i_editor_contract =
[
    [ "GetContent", "interface_power_pad_1_1_core_1_1_contracts_1_1_i_editor_contract.html#a17f98531ce53aa41ea94591a8d447a17", null ],
    [ "SetContent", "interface_power_pad_1_1_core_1_1_contracts_1_1_i_editor_contract.html#aba72840a2b1031fe7a26927884a7775b", null ],
    [ "WordCount", "interface_power_pad_1_1_core_1_1_contracts_1_1_i_editor_contract.html#a689ac1aebc7ce0ed842b49a3a4230ecd", null ]
];