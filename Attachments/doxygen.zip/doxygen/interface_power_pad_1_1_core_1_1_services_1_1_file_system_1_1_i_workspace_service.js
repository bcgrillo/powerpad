var interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service =
[
    [ "CreateDocument", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service.html#a3a83ccae4f91d41a03c52288b3e8c204", null ],
    [ "CreateFolder", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service.html#a6f2c6798573b3f3803bd99a80a7b2d54", null ],
    [ "DeleteDocument", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service.html#a0d34ef193a62b43672c67a724e5d7ddd", null ],
    [ "DeleteFolder", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service.html#a039322f08c14174778ac3b1b1dcdce67", null ],
    [ "MoveDocument", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service.html#a8eb185c2f61a8f16e47f3c55c7e7379e", null ],
    [ "MoveFolder", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service.html#a5e07deece14215ee8ab47c1b2fb904b5", null ],
    [ "OpenWorkspace", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service.html#a819a4ff30947cb115e2329c612ba2fca", null ],
    [ "RenameDocument", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service.html#ae15d21844d311d820147d6b28b2f61fa", null ],
    [ "RenameFolder", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service.html#a42799295d94f3d59fc446e3b6d2675e7", null ],
    [ "SetPosition", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service.html#a370424131460d20e9f39596fb7ac60a5", null ],
    [ "SetPosition", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service.html#a1feaafbcc8c53b87a2a934e4162ac575", null ],
    [ "Root", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_workspace_service.html#ac15f7abc6b3773039bc7c1c064b51008", null ]
];