var namespace_power_pad_1_1_win_u_i_1_1_pages_1_1_providers =
[
    [ "GitHubAddModelPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_git_hub_add_model_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_git_hub_add_model_page" ],
    [ "GitHubModelsPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_git_hub_models_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_git_hub_models_page" ],
    [ "HuggingFaceAddModelPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_add_model_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_add_model_page" ],
    [ "HuggingFaceModelsPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_models_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_models_page" ],
    [ "IModelProviderPage", "interface_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_i_model_provider_page.html", "interface_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_i_model_provider_page" ],
    [ "OllamaAddModelPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_ollama_add_model_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_ollama_add_model_page" ],
    [ "OllamaModelsPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_ollama_models_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_ollama_models_page" ],
    [ "OpenAIAddModelPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_open_a_i_add_model_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_open_a_i_add_model_page" ],
    [ "OpenAIModelsPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_open_a_i_models_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_open_a_i_models_page" ]
];