var interface_power_pad_1_1_core_1_1_services_1_1_config_1_1_i_config_store_service =
[
    [ "GetConfigStore", "interface_power_pad_1_1_core_1_1_services_1_1_config_1_1_i_config_store_service.html#afdf47b3488e8e8ee4a1a501439a49a4c", null ],
    [ "StoreConfigs", "interface_power_pad_1_1_core_1_1_services_1_1_config_1_1_i_config_store_service.html#a9d64dd6dcb7a919e687596eb6c1fa717", null ]
];