var class_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers_1_1_ollama_models_view_model =
[
    [ "OllamaModelsViewModel", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers_1_1_ollama_models_view_model.html#ac74d483b58ac97a9fd5bea814d81eac8", null ],
    [ "OllamaModelsViewModel", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers_1_1_ollama_models_view_model.html#aa45e61339886040ee5374e34cf296519", null ],
    [ "AddModel", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers_1_1_ollama_models_view_model.html#a04ff84b5dc47cb0b882a8ab34f427c7d", null ],
    [ "RefreshModels", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers_1_1_ollama_models_view_model.html#a43d2b4588d57f28b286a83f3bb994ad7", null ],
    [ "RemoveModel", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers_1_1_ollama_models_view_model.html#a0ed9f961e026f2ad5ee980bc3f42cc0e", null ],
    [ "SearchModels", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers_1_1_ollama_models_view_model.html#a2b743429686d43c9685c911aa35a2872", null ],
    [ "RefreshModelsCommand", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers_1_1_ollama_models_view_model.html#ada4a34908bd787daf90783596acffa00", null ]
];