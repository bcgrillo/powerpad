var namespaces_dup =
[
    [ "PowerPad", "namespace_power_pad.html", "namespace_power_pad" ]
];