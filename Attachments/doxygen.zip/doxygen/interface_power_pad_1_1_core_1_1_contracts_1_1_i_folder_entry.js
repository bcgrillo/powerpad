var interface_power_pad_1_1_core_1_1_contracts_1_1_i_folder_entry =
[
    [ "Name", "interface_power_pad_1_1_core_1_1_contracts_1_1_i_folder_entry.html#a33ac7ab417e6926e79cf37ce4a42e29a", null ],
    [ "Parent", "interface_power_pad_1_1_core_1_1_contracts_1_1_i_folder_entry.html#a292b3075fe9c9988bc9a2754acec1266", null ],
    [ "Path", "interface_power_pad_1_1_core_1_1_contracts_1_1_i_folder_entry.html#aed3d1303dbf70497eace17457087db63", null ],
    [ "Position", "interface_power_pad_1_1_core_1_1_contracts_1_1_i_folder_entry.html#ad398adc76ff8b3de6a9b42d9ed422e38", null ],
    [ "Status", "interface_power_pad_1_1_core_1_1_contracts_1_1_i_folder_entry.html#ad2c5ce117e8853060e0b82b3199ac1b3", null ],
    [ "Type", "interface_power_pad_1_1_core_1_1_contracts_1_1_i_folder_entry.html#a16e755e95ad7b4141cb63f638d4d333b", null ]
];