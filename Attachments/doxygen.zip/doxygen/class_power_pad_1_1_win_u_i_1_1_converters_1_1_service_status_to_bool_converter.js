var class_power_pad_1_1_win_u_i_1_1_converters_1_1_service_status_to_bool_converter =
[
    [ "Convert", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_service_status_to_bool_converter.html#a1420b0979d8586772b353c980bc5432e", null ],
    [ "ConvertBack", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_service_status_to_bool_converter.html#ada7cbb373e5e159130a3e14f396ed88b", null ]
];