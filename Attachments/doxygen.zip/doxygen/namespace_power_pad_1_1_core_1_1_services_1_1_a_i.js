var namespace_power_pad_1_1_core_1_1_services_1_1_a_i =
[
    [ "AzureAIService", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_azure_a_i_service.html", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_azure_a_i_service" ],
    [ "IChatService", "interface_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_i_chat_service.html", "interface_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_i_chat_service" ],
    [ "IOllamaService", "interface_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_i_ollama_service.html", "interface_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_i_ollama_service" ],
    [ "OllamaService", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_ollama_service.html", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_ollama_service" ],
    [ "OpenAIService", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_open_a_i_service.html", "class_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_open_a_i_service" ]
];