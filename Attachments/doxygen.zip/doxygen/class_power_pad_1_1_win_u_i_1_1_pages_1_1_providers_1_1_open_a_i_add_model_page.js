var class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_open_a_i_add_model_page =
[
    [ "OpenAIAddModelPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_open_a_i_add_model_page.html#a4a69e99da0c0ce7c5717f30c617b711f", null ],
    [ "CloseModelInfoViewer", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_open_a_i_add_model_page.html#a27aeca2dca62c8424d3e7fcf0e283f96", null ],
    [ "GetSearchTextBox", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_open_a_i_add_model_page.html#a26952aaade31795d7e555c6edab9a806", null ],
    [ "Search", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_open_a_i_add_model_page.html#aa2fe1863000ea0cf8108b57e0b73d927", null ]
];