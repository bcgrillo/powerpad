var class_power_pad_1_1_win_u_i_1_1_converters_1_1_float_to_double_converter =
[
    [ "Convert", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_float_to_double_converter.html#a8ab19b47e0860328205b36701c6c1a59", null ],
    [ "ConvertBack", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_float_to_double_converter.html#af35575ac4ad3424d62bd70ad87305b77", null ]
];