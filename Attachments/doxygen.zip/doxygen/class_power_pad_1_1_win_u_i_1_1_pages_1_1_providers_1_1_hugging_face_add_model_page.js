var class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_add_model_page =
[
    [ "HuggingFaceAddModelPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_add_model_page.html#a45050722faed7f4441ff3b366f0e57f7", null ],
    [ "CloseModelInfoViewer", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_add_model_page.html#a73e934b0ed007c0e918e36c2dfc0ca8c", null ],
    [ "GetSearchTextBox", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_add_model_page.html#a690aaa016b4b3cfcd68aba3e5a9f6710", null ],
    [ "Search", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_hugging_face_add_model_page.html#a65bf658c2d6946237229f34c296bf64d", null ]
];