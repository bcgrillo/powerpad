var interface_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_i_ollama_service =
[
    [ "DeleteModel", "interface_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_i_ollama_service.html#add036113dfdb20d275b3baa20a1b92e2", null ],
    [ "DownloadModel", "interface_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_i_ollama_service.html#a526c1c95f74baf41bc6a4511839ea84b", null ],
    [ "GetInstalledModels", "interface_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_i_ollama_service.html#a1d85b04081f911657192982fdb49e5ae", null ],
    [ "Start", "interface_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_i_ollama_service.html#aa8eed655fd379b32a43d5b2c331eae32", null ],
    [ "Stop", "interface_power_pad_1_1_core_1_1_services_1_1_a_i_1_1_i_ollama_service.html#a86cb54cc22d93f7df4313728dbb2a5aa", null ]
];