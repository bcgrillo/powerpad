var namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i =
[
    [ "Providers", "namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers.html", "namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i_1_1_providers" ],
    [ "MenuOption", "namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i.html#a9c47916a3d43feafb245ecbe13b78905", [
      [ "AvailableModels", "namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i.html#a9c47916a3d43feafb245ecbe13b78905ab3aef84a13116883870d1026850901d9", null ],
      [ "AddModels", "namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i.html#a9c47916a3d43feafb245ecbe13b78905a3cea3aff4f7573416501764680ed3a21", null ]
    ] ],
    [ "ModelsMenuOption", "namespace_power_pad_1_1_win_u_i_1_1_view_models_1_1_a_i.html#a79504183d98fb856b232e119c2ada68d", null ]
];