var class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service =
[
    [ "WorkspaceService", "class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service.html#a1a02c236247d694583b3666a1c2cf2fc", null ],
    [ "CreateDocument", "class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service.html#a161d3181d183248aee78c3b1faa673da", null ],
    [ "CreateFolder", "class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service.html#a4d0103ca2b48a9e648c9be12599270ec", null ],
    [ "DeleteDocument", "class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service.html#ac9f37ef6caff8a038f1fbc28a445d4f5", null ],
    [ "DeleteFolder", "class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service.html#a9c991893d17db8555e6cae3715359f6b", null ],
    [ "MoveDocument", "class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service.html#abe0e463060b57b22a3b84a1f2d718e76", null ],
    [ "MoveFolder", "class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service.html#ab9d8f82ee5757da583ae56779879cd26", null ],
    [ "OpenWorkspace", "class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service.html#a48be893709022475df7ad4a77401f9ab", null ],
    [ "RenameDocument", "class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service.html#a3ca535a9306b55a0c390ef84fd99b155", null ],
    [ "RenameFolder", "class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service.html#adec98284984c7fbe41dc42ac5e1a5547", null ],
    [ "SetPosition", "class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service.html#a5627f465614a8068a07bc0848e66a7f0", null ],
    [ "SetPosition", "class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service.html#a8753c9a52369037e34f0fe03696a24ab", null ],
    [ "Root", "class_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_workspace_service.html#ad23909a856b4f51b230cb58ab43aad71", null ]
];