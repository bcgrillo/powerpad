var class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_editor_control =
[
    [ "AutoSave", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_editor_control.html#aa70e3ce0a28f47656364b8cab8b68dd2", null ],
    [ "Dispose", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_editor_control.html#a58a574e815afbb3aec3d99121717f521", null ],
    [ "Dispose", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_editor_control.html#a87449c6847808cd6919a021a6224a2c6", null ],
    [ "GetContent", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_editor_control.html#a3ee6df14a585ef1e7a3553fb2e74bca4", null ],
    [ "SetContent", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_editor_control.html#ad39d39c19735405e269a9ea103874c40", null ],
    [ "SetFocus", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_editor_control.html#aa3abbf9f774537d98a840b0909fd6eea", null ],
    [ "WordCount", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_editor_control.html#aa1f09bafc121980f05799c80d4462ccf", null ],
    [ "IsActive", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_editor_control.html#ac9dd8f4156404cc983cca21bb54f7e9f", null ],
    [ "IsDirty", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_editor_control.html#a23eb10206693aa709c387de7fe1a7358", null ],
    [ "LastSaveTime", "class_power_pad_1_1_win_u_i_1_1_components_1_1_editors_1_1_editor_control.html#a65632c66aba189255999bb38e448b23f", null ]
];