var class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_settings_view_model =
[
    [ "SettingsViewModel", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_settings_view_model.html#a6c0d93e3f6910b5441c0226672ceb982", null ],
    [ "TestConnections", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_settings_view_model.html#a40ce05ef1e1ccb31674f321db51afd4b", null ],
    [ "General", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_settings_view_model.html#a7e5d0b67d87c7527fc7754da83ee312e", null ],
    [ "IsAIAvailable", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_settings_view_model.html#a27601ca3cda8786396545756970644ef", null ],
    [ "Models", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_settings_view_model.html#a79aaa6e3eaae74fe717511d204cef7fe", null ]
];