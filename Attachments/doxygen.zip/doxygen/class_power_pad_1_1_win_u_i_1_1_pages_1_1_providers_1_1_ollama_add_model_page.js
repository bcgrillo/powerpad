var class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_ollama_add_model_page =
[
    [ "OllamaAddModelPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_ollama_add_model_page.html#ab295a333498a41797ce38d056e45c3b8", null ],
    [ "CloseModelInfoViewer", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_ollama_add_model_page.html#a2f740adda4e510f6c30826ae51a0b0d3", null ],
    [ "GetSearchTextBox", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_ollama_add_model_page.html#a949c285a9309c636d626569f65378e62", null ],
    [ "Search", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_ollama_add_model_page.html#aec740bb9398d665114d1b7605dc6caa3", null ]
];