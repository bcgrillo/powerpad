var class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_models_settings_view_model =
[
    [ "AvailableModels", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_models_settings_view_model.html#a4613269e0afd960594cd491493a79dcb", null ],
    [ "DefaultModel", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_models_settings_view_model.html#a34432d020fc8d0316bb4c215bcce7b2c", null ],
    [ "DefaultParameters", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_models_settings_view_model.html#ab1fd48dddc9a15e4b2d6311f5e21deb4", null ],
    [ "SendDefaultParameters", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_models_settings_view_model.html#a88643ab76093a0f976f3e8fa182e3b49", null ],
    [ "DefaultModelChanged", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_models_settings_view_model.html#a59044d5a2c58507673abafee66fb53e2", null ],
    [ "ModelAvailabilityChanged", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_settings_1_1_models_settings_view_model.html#a3f0a1433a2307d0bcfb181788ea42e65", null ]
];