var class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_git_hub_models_page =
[
    [ "GitHubModelsPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_git_hub_models_page.html#ac536a5089c8cb10f9ecf51d206ba587b", null ],
    [ "CloseModelInfoViewer", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_git_hub_models_page.html#aaedf7977488dd28c73c4978ab66e690a", null ]
];