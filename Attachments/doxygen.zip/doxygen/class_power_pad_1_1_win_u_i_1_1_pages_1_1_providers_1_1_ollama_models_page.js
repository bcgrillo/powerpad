var class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_ollama_models_page =
[
    [ "OllamaModelsPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_ollama_models_page.html#a8a6582fef265a0bc52ab4df8254394ce", null ],
    [ "CloseModelInfoViewer", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_providers_1_1_ollama_models_page.html#a698363e7554f1d14d01ded69311ec4ac", null ]
];