var namespace_power_pad_1_1_win_u_i =
[
    [ "Components", "namespace_power_pad_1_1_win_u_i_1_1_components.html", "namespace_power_pad_1_1_win_u_i_1_1_components" ],
    [ "Configuration", "namespace_power_pad_1_1_win_u_i_1_1_configuration.html", "namespace_power_pad_1_1_win_u_i_1_1_configuration" ],
    [ "Converters", "namespace_power_pad_1_1_win_u_i_1_1_converters.html", "namespace_power_pad_1_1_win_u_i_1_1_converters" ],
    [ "Dialogs", "namespace_power_pad_1_1_win_u_i_1_1_dialogs.html", "namespace_power_pad_1_1_win_u_i_1_1_dialogs" ],
    [ "Helpers", "namespace_power_pad_1_1_win_u_i_1_1_helpers.html", null ],
    [ "Messages", "namespace_power_pad_1_1_win_u_i_1_1_messages.html", [
      [ "FolderEntryChanged", "namespace_power_pad_1_1_win_u_i_1_1_messages.html#a6f192e4b915a6a6cedf2e433426c829a", null ],
      [ "FolderEntryCreated", "namespace_power_pad_1_1_win_u_i_1_1_messages.html#aca0dd2638bc9f935e7ce20bd64885a01", null ],
      [ "FolderEntryDeleted", "namespace_power_pad_1_1_win_u_i_1_1_messages.html#a33949c05e2917d10bcab6ba69b859676", null ]
    ] ],
    [ "Pages", "namespace_power_pad_1_1_win_u_i_1_1_pages.html", "namespace_power_pad_1_1_win_u_i_1_1_pages" ],
    [ "ViewModels", "namespace_power_pad_1_1_win_u_i_1_1_view_models.html", "namespace_power_pad_1_1_win_u_i_1_1_view_models" ],
    [ "App", "class_power_pad_1_1_win_u_i_1_1_app.html", "class_power_pad_1_1_win_u_i_1_1_app" ],
    [ "MainWindow", "class_power_pad_1_1_win_u_i_1_1_main_window.html", "class_power_pad_1_1_win_u_i_1_1_main_window" ],
    [ "PopupWindow", "class_power_pad_1_1_win_u_i_1_1_popup_window.html", "class_power_pad_1_1_win_u_i_1_1_popup_window" ]
];