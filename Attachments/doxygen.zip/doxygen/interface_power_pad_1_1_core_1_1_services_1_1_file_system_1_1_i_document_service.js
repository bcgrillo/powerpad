var interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_document_service =
[
    [ "AutosaveDocument", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_document_service.html#a3bbe527e44be30b286000b2346aa19a8", null ],
    [ "LoadDocument", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_document_service.html#a2f5987e2b82c0f01d9ceb972439c0455", null ],
    [ "SaveDocument", "interface_power_pad_1_1_core_1_1_services_1_1_file_system_1_1_i_document_service.html#adb2e7f6c4581626e5c2d27f9e531636f", null ]
];