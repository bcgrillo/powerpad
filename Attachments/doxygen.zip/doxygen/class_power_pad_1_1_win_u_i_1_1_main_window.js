var class_power_pad_1_1_win_u_i_1_1_main_window =
[
    [ "MainWindow", "class_power_pad_1_1_win_u_i_1_1_main_window.html#a144ea2a467dbd8ad7f075db6cc462fab", null ],
    [ "SetBackdrop", "class_power_pad_1_1_win_u_i_1_1_main_window.html#a44cd7010003baced814e896ab4511165", null ],
    [ "ShowNotes", "class_power_pad_1_1_win_u_i_1_1_main_window.html#aae452d012eed4935a0d1c5276b0e6c72", null ]
];