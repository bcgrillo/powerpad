var class_power_pad_1_1_win_u_i_1_1_components_1_1_a_i_model_click_event_args =
[
    [ "AIModelClickEventArgs", "class_power_pad_1_1_win_u_i_1_1_components_1_1_a_i_model_click_event_args.html#a35d96913b9557020397d2a887bd32aa9", null ],
    [ "Model", "class_power_pad_1_1_win_u_i_1_1_components_1_1_a_i_model_click_event_args.html#a75c9022dac041572902be83516fcf440", null ]
];