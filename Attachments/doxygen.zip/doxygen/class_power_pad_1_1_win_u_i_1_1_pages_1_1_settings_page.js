var class_power_pad_1_1_win_u_i_1_1_pages_1_1_settings_page =
[
    [ "SettingsPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_settings_page.html#a70edbbaf282fa64e8dbc092801e83a23", null ],
    [ "Dispose", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_settings_page.html#aeabf21ca92f4664a2c037f5039c91233", null ]
];