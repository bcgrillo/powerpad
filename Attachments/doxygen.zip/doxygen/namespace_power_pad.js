var namespace_power_pad =
[
    [ "Core", "namespace_power_pad_1_1_core.html", "namespace_power_pad_1_1_core" ],
    [ "WinUI", "namespace_power_pad_1_1_win_u_i.html", "namespace_power_pad_1_1_win_u_i" ]
];