var interface_power_pad_1_1_win_u_i_1_1_pages_1_1_i_toggle_menu_page =
[
    [ "ToggleNavigationVisibility", "interface_power_pad_1_1_win_u_i_1_1_pages_1_1_i_toggle_menu_page.html#a5d2fb6b2ed674b085ce69227424c947e", null ],
    [ "NavigationWidth", "interface_power_pad_1_1_win_u_i_1_1_pages_1_1_i_toggle_menu_page.html#a643b72176a79a30c316ad3da3793faa4", null ]
];