var class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_new_entry_parameters =
[
    [ "Content", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_new_entry_parameters.html#a9586f1c14a5c7342a34c8b490d425824", null ],
    [ "DocumentType", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_new_entry_parameters.html#a2b6ed22031e44499eecf1a8347baacfd", null ],
    [ "Name", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_new_entry_parameters.html#aa9938165ac9115b8516411d08d50709b", null ],
    [ "Parent", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_new_entry_parameters.html#a708eb4f9e6ad860843a7c9dbe1e83c7e", null ],
    [ "Type", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_new_entry_parameters.html#a34f8439c05deb22f311d6469cb58c583", null ]
];