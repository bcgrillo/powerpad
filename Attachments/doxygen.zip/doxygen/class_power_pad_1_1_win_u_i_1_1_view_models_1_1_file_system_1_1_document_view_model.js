var class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model =
[
    [ "DocumentViewModel", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model.html#a2bb1f25a89a38c224472c5f87cdc34a8", null ],
    [ "NameChanged", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model.html#a5e64aed43036864c0142953c0d856308", null ],
    [ "Receive", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model.html#a82f9ba724283974642995cd3ee970024", null ],
    [ "AutosaveCommand", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model.html#a9b5f2b30168ee89686485c89fb9573c1", null ],
    [ "CanSave", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model.html#aafcb9ca2252a135a1202f20e3608a434", null ],
    [ "LastSaveTime", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model.html#ab884c04a1165864643aa426d76c4488f", null ],
    [ "Name", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model.html#ae0c29ab319fd4488564490943d854454", null ],
    [ "NextContent", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model.html#aff52ee39d380098e9ca9c1062affc8bd", null ],
    [ "PreviousContent", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model.html#aedc410db3efd05e1fc96714d63655d9a", null ],
    [ "RenameCommand", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model.html#a1b3670c49322df1c263b64433f4e72f8", null ],
    [ "SaveCommand", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model.html#aed949a535b8c4f6556ef4df4c860239a", null ],
    [ "Status", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_document_view_model.html#a3dc1cf7e5b7b3dea7230220654672448", null ]
];