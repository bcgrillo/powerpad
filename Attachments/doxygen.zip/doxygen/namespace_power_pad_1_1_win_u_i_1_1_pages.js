var namespace_power_pad_1_1_win_u_i_1_1_pages =
[
    [ "Providers", "namespace_power_pad_1_1_win_u_i_1_1_pages_1_1_providers.html", "namespace_power_pad_1_1_win_u_i_1_1_pages_1_1_providers" ],
    [ "AgentsPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_agents_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_agents_page" ],
    [ "DisposablePage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_disposable_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_disposable_page" ],
    [ "IToggleMenuPage", "interface_power_pad_1_1_win_u_i_1_1_pages_1_1_i_toggle_menu_page.html", "interface_power_pad_1_1_win_u_i_1_1_pages_1_1_i_toggle_menu_page" ],
    [ "ModelsPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_models_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_models_page" ],
    [ "PopupEditorPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_popup_editor_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_popup_editor_page" ],
    [ "SettingsPage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_settings_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_settings_page" ],
    [ "WorkspacePage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_workspace_page.html", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_workspace_page" ]
];