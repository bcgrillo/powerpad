var class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_draft_document_view_model =
[
    [ "Content", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_draft_document_view_model.html#a96c188cc36c7359bf01b67176f6079ac", null ],
    [ "NextContent", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_draft_document_view_model.html#a374d5c281fdba2f4da6db361a34eb9f3", null ],
    [ "PreviousContent", "class_power_pad_1_1_win_u_i_1_1_view_models_1_1_file_system_1_1_draft_document_view_model.html#a69523cca718e565993604ce9af143731", null ]
];