var class_power_pad_1_1_win_u_i_1_1_pages_1_1_workspace_page =
[
    [ "WorkspacePage", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_workspace_page.html#ac2018191c573401c3cc98a981e4745d1", null ],
    [ "Dispose", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_workspace_page.html#a6ab4ea9d02f3a7fa2d0a2d3c58ea02e9", null ],
    [ "ToggleNavigationVisibility", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_workspace_page.html#a9289d533b62b8f995ea9478af03c6cd5", null ],
    [ "NavigationWidth", "class_power_pad_1_1_win_u_i_1_1_pages_1_1_workspace_page.html#ab6a9f1ece45c25ee4565d1101e09315c", null ]
];