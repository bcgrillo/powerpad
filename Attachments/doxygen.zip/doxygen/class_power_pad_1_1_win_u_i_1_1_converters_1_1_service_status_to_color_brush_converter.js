var class_power_pad_1_1_win_u_i_1_1_converters_1_1_service_status_to_color_brush_converter =
[
    [ "Convert", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_service_status_to_color_brush_converter.html#a04b4f0aa172d4ec1451e375f1b6de064", null ],
    [ "ConvertBack", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_service_status_to_color_brush_converter.html#a409d40fb50899c5c595b31e461200ea1", null ]
];