var class_power_pad_1_1_win_u_i_1_1_components_1_1_workspace_control =
[
    [ "WorkspaceControl", "class_power_pad_1_1_win_u_i_1_1_components_1_1_workspace_control.html#a47d0544718177b56f61e572aead6f5e2", null ],
    [ "Receive", "class_power_pad_1_1_win_u_i_1_1_components_1_1_workspace_control.html#ad4287078db3ed0bb22a0e7bcf554c72c", null ],
    [ "Receive", "class_power_pad_1_1_win_u_i_1_1_components_1_1_workspace_control.html#a524648b4cc981669b47b1572773f034c", null ],
    [ "ItemInvoked", "class_power_pad_1_1_win_u_i_1_1_components_1_1_workspace_control.html#a6cb9ac6c66ed80a5023f483e4ed3f10c", null ]
];