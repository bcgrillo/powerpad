var class_power_pad_1_1_win_u_i_1_1_converters_1_1_service_status_to_string_converter =
[
    [ "Convert", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_service_status_to_string_converter.html#a34e8fc572127c4dbb61fcd468e7740b3", null ],
    [ "ConvertBack", "class_power_pad_1_1_win_u_i_1_1_converters_1_1_service_status_to_string_converter.html#ab1ad54d0dba782b0501da45313ed4b55", null ]
];