var namespace_power_pad_1_1_core =
[
    [ "Contracts", "namespace_power_pad_1_1_core_1_1_contracts.html", "namespace_power_pad_1_1_core_1_1_contracts" ],
    [ "Helpers", "namespace_power_pad_1_1_core_1_1_helpers.html", null ],
    [ "Models", "namespace_power_pad_1_1_core_1_1_models.html", "namespace_power_pad_1_1_core_1_1_models" ],
    [ "Services", "namespace_power_pad_1_1_core_1_1_services.html", "namespace_power_pad_1_1_core_1_1_services" ]
];